  
// ===============================================================================
// public
// Below public will hold all of the friends participating in the survey".
// 
// ===============================================================================
// Export the array to make it avaliible to other files using require. 


var allFriendsArray = [
    {
        "name": "Ahmed",
        "photo": "./photos/manSketch1.jpg",
        "scores": [
        "5",
        "1",
        "4",
        "4",
        "5",
        "1",
        "2",
        "5",
        "4",
        "1"
                ]
        },
        {
        "name": "Jacob Deming",
        "photo": "./photos/manSketch2.jpg",
        "scores": [
        "4",
        "2",
        "5",
        "1",
        "3",
        "2",
        "2",
        "1",
        "3",
        "2"
                ]
        },
        {
        "name": "Jeremiah Scanlon",
        "photo": "./photos/manSketch3.jpg",
        "scores": [
        "5",
        "2",
        "2",
        "2",
        "4",
        "1",
        "3",
        "2",
        "5",
        "5"
                ]
        },
        {
        "name": "Louis T. Delia",
        "photo": "./photos/manSketch4.png",
        "scores": [
        "3",
        "3",
        "4",
        "2",
        "2",
        "1",
        "3",
        "2",
        "2",
        "3"
                ]
        },
        {
        "name": "Lou Ritter",
        "photo": "./photos/manSketch5.jpg",
        "scores": [
        "4",
        "3",
        "4",
        "1",
        "5",
        "2",
        "5",
        "3",
        "1",
        "4"
                 ]
        },
        {
        "name": "Jordan Biason",
        "photo": "./photos/womanSketch1.jpg",
        "scores": [
        "4",
        "4",
        "2",
        "3",
        "2",
        "2",
        "3",
        "2",
        "4",
        "5"
                  ]
        },
        {
        "name": "Jalin",
        "photo":"./photos/womanSketch2.jpg",
        "scores": [
        "1",
        "3",
        "4",
        "4",
        "3",
        "5",
        "3",
        "2",
        "4",
        "2"
                ]
        },
        {
        "name": "Tommy Vinyard",
        "photo": "./photos/manSketch6.jpg",
        "scores": [
        "1",
        "2",
        "2",
        "1",
        "5",
        "2",
        "2",
        "3",
        "2",
        "3"
                ]
        },
        {
        "name": "sstorysmith",
        "photo": "./photos/linkedinheadshot.jpg",
        "scores": [
        "1",
        "2",
        "3",
        "4",
        "5",
        "1",
        "2",
        "3",
        "4",
        "5"
                     ]
        }
                      ];
  
    