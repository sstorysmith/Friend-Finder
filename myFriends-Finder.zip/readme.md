# Friend Finder - Node and Express Servers
​
### Overview
Steps for academic Class:
  $npm - i   // this crates the package.json file with dependencies named
  $npm install express 
  $node install path 


node Express is used to handle routing.

The flow of this application:
SERVER side    CLIENT side
  1. start the SERVER listening on port 3000 with routes
              2. connect to the port on the CLIENT side
              3. display home.html
              4. click on display Friends Button
              5. submits the path "/friends" to the SERVER
  6."app.get /friends" executes href file to display the raw data of /data/friends.js source
              7. click on Survey Button
              8. submits the path "/survey" to the SERVER
  9. "app.post "/survey" sends the survey.html file to client
              10 survey.html is displayed and user enters answers 
              11. user clicks the submit button which sends a post to server
  12 "app.post /survey" calls the determineCompatibility program
  13 send display modal
​
This is a compatibility-based "FriendFinder" application -- basically a dating app. The full-stack site will take in results from a user's survey, then compare their answers with those from other users. The app will then display the name and picture of the user with the best overall match.
​

​
​
### Before You Begin
​
* Check out [this demo version of the site](https://friend-finder-fsf.herokuapp.com/). Use this as a model for how we expect your assignment look and operate.
​


### Submission on BCS
​
* Please submit both the deployed Heroku link to your homework AND the link to the Github Repository!
​

​
### Reminder: Submission on BCS
​
* Please submit both the deployed Heroku link to your homework AND the link to the Github Repository!
​
- - -
​
### Minimum Requirements
​
Attempt to complete homework assignment as described in instructions. If unable to complete certain portions, please pseudocode these portions to describe what remains to be completed. Adding a README.md as well as adding this homework to your portfolio are required as well and more information can be found below. **This assignment must be deployed.**
​
- - -
​

​
Please see [Heroku’s Account Verification Information](https://devcenter.heroku.com/articles/account-verification) for more details.
​
See the [Supplemental Heroku Deployment Guide](../../03-Supplemental/HerokuGuide.md) for in-detail deployment instructions.
​

​
### Add To Your Portfolio
​
After completing the homework please add the piece to your portfolio. Make sure to add a link to your updated portfolio in the comments section of your homework so the TAs can easily ensure you completed this step when they are grading the assignment. To receive an 'A' on any assignment, you must link to it from your portfolio.
​






